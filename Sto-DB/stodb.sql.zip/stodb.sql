-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 25, 2018 alle 15:55
-- Versione del server: 10.1.21-MariaDB
-- Versione PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stodb`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `accumulosaldaturadp`
--

CREATE TABLE `accumulosaldaturadp` (
  `id` int(11) NOT NULL,
  `codiceTubo` varchar(128) COLLATE utf8_bin NOT NULL,
  `idTelaio` int(11) NOT NULL,
  `descrizione` varchar(100) COLLATE utf8_bin NOT NULL,
  `diametro` float NOT NULL,
  `peso` float NOT NULL,
  `lunghezza` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `allarmirt`
--

CREATE TABLE `allarmirt` (
  `id` int(11) NOT NULL,
  `type` varchar(100) COLLATE utf8_bin NOT NULL,
  `data` datetime NOT NULL,
  `idMacchina` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `assemblaggiodp`
--

CREATE TABLE `assemblaggiodp` (
  `id` int(11) NOT NULL,
  `idTelaio` int(11) NOT NULL,
  `idScatola` varchar(20) COLLATE utf8_bin NOT NULL,
  `startTime` datetime NOT NULL,
  `endTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `lasercutdp`
--

CREATE TABLE `lasercutdp` (
  `id` int(11) NOT NULL,
  `codiceTubo` varchar(128) COLLATE utf8_bin NOT NULL,
  `idAssegnazione` int(11) NOT NULL,
  `startTime` datetime NOT NULL,
  `endTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `lavorooperazioni`
--

CREATE TABLE `lavorooperazioni` (
  `id` int(11) NOT NULL,
  `workstationId` varchar(20) COLLATE utf8_bin NOT NULL,
  `operationId` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `listaallarmi`
--

CREATE TABLE `listaallarmi` (
  `idAllarme` varchar(20) COLLATE utf8_bin NOT NULL,
  `descrizione` varchar(100) COLLATE utf8_bin NOT NULL,
  `blocksystem` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `listaprocessi`
--

CREATE TABLE `listaprocessi` (
  `id` varchar(20) COLLATE utf8_bin NOT NULL,
  `descrizione` varchar(100) COLLATE utf8_bin NOT NULL,
  `valoreMax` int(11) NOT NULL,
  `valoreMin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `magazzinomateriali`
--

CREATE TABLE `magazzinomateriali` (
  `codiceBarre` varchar(128) COLLATE utf8_bin NOT NULL,
  `descrizione` varchar(100) COLLATE utf8_bin NOT NULL,
  `diametro` float NOT NULL,
  `peso` float NOT NULL,
  `lunghezza` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `mps`
--

CREATE TABLE `mps` (
  `id` varchar(20) COLLATE utf8_bin NOT NULL,
  `start` datetime NOT NULL,
  `dueDate` datetime NOT NULL,
  `quantita` int(11) NOT NULL,
  `tipoTelaio` varchar(100) COLLATE utf8_bin NOT NULL,
  `colore` varchar(100) COLLATE utf8_bin NOT NULL,
  `priorita` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `operazioni`
--

CREATE TABLE `operazioni` (
  `id` varchar(20) COLLATE utf8_bin NOT NULL,
  `descrizione` varchar(500) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `percorsi`
--

CREATE TABLE `percorsi` (
  `id` int(11) NOT NULL,
  `origine` varchar(20) COLLATE utf8_bin NOT NULL,
  `destinazione` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `percorsiveicoli`
--

CREATE TABLE `percorsiveicoli` (
  `id` int(11) NOT NULL,
  `idPercorso` int(11) NOT NULL,
  `idVeicolo` varchar(20) COLLATE utf8_bin NOT NULL,
  `tempoAssegnazione` datetime NOT NULL,
  `tempoPartenza` datetime NOT NULL,
  `tempoArrivo` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `posizioni`
--

CREATE TABLE `posizioni` (
  `id` int(11) NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  `z` varchar(5) COLLATE utf8_bin NOT NULL,
  `idScatola` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `processirt`
--

CREATE TABLE `processirt` (
  `id` int(11) NOT NULL,
  `type` varchar(20) COLLATE utf8_bin NOT NULL,
  `date` datetime NOT NULL,
  `value` int(11) NOT NULL,
  `idMacchina` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `prodottifinitidp`
--

CREATE TABLE `prodottifinitidp` (
  `id` int(11) NOT NULL,
  `idAssemblaggio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `ricette`
--

CREATE TABLE `ricette` (
  `tipoTelaio` varchar(100) COLLATE utf8_bin NOT NULL,
  `quantitaTubi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Struttura della tabella `routing`
--

CREATE TABLE `routing` (
  `id` varchar(20) COLLATE utf8_bin NOT NULL,
  `idLotto` varchar(20) COLLATE utf8_bin NOT NULL,
  `idPezzo` varchar(128) COLLATE utf8_bin NOT NULL,
  `step` int(11) NOT NULL,
  `durata` int(11) NOT NULL,
  `durataSetUp` int(11) NOT NULL,
  `opMacchina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `sald_essdp`
--

CREATE TABLE `sald_essdp` (
  `idTelaio` int(11) NOT NULL,
  `startTime` datetime NOT NULL,
  `endTime` datetime NOT NULL,
  `stato` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Struttura della tabella `scatole`
--

CREATE TABLE `scatole` (
  `id` varchar(20) COLLATE utf8_bin NOT NULL,
  `tipo` varchar(100) COLLATE utf8_bin NOT NULL,
  `idCambio` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `idRuote` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `idFiniture` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `idSellino` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `idCatena` varchar(20) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `statoordini`
--

CREATE TABLE `statoordini` (
  `id` varchar(20) COLLATE utf8_bin NOT NULL,
  `idLotto` varchar(20) COLLATE utf8_bin NOT NULL,
  `startPianificata` datetime NOT NULL,
  `dueDatePianificata` datetime NOT NULL,
  `startEffettiva` datetime NOT NULL,
  `dueDateEffettiva` datetime NOT NULL,
  `quantitaDesiderata` int(11) NOT NULL,
  `quantitaProdotta` int(11) NOT NULL,
  `tipoTelaio` varchar(100) COLLATE utf8_bin NOT NULL,
  `stato` varchar(100) COLLATE utf8_bin NOT NULL,
  `descrizione` varchar(200) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `stazionilavoro`
--

CREATE TABLE `stazionilavoro` (
  `id` varchar(20) COLLATE utf8_bin NOT NULL,
  `zonaLavoro` varchar(100) COLLATE utf8_bin NOT NULL,
  `descrizione` varchar(200) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `storicoproduzione`
--

CREATE TABLE `storicoproduzione` (
  `id` int(11) NOT NULL,
  `idLotto` varchar(20) COLLATE utf8_bin NOT NULL,
  `idStatoOrdine` varchar(20) COLLATE utf8_bin NOT NULL,
  `startTime` datetime NOT NULL,
  `finishTime` datetime NOT NULL,
  `quantita` int(11) NOT NULL,
  `tipoTelaio` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struttura della tabella `veicoli`
--

CREATE TABLE `veicoli` (
  `id` varchar(20) COLLATE utf8_bin NOT NULL,
  `tipo` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `accumulosaldaturadp`
--
ALTER TABLE `accumulosaldaturadp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `codiceTubo` (`codiceTubo`),
  ADD KEY `idSaldatura` (`idTelaio`);

--
-- Indici per le tabelle `allarmirt`
--
ALTER TABLE `allarmirt`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idMacchina` (`idMacchina`),
  ADD KEY `type` (`type`);

--
-- Indici per le tabelle `assemblaggiodp`
--
ALTER TABLE `assemblaggiodp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idMagazzino` (`idTelaio`),
  ADD KEY `idScatola` (`idScatola`);

--
-- Indici per le tabelle `lasercutdp`
--
ALTER TABLE `lasercutdp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `codiceTubo` (`codiceTubo`),
  ADD KEY `idAssegnazione` (`idAssegnazione`);

--
-- Indici per le tabelle `lavorooperazioni`
--
ALTER TABLE `lavorooperazioni`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workstationId` (`workstationId`),
  ADD KEY `operationId` (`operationId`);

--
-- Indici per le tabelle `listaallarmi`
--
ALTER TABLE `listaallarmi`
  ADD PRIMARY KEY (`idAllarme`);

--
-- Indici per le tabelle `listaprocessi`
--
ALTER TABLE `listaprocessi`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `magazzinomateriali`
--
ALTER TABLE `magazzinomateriali`
  ADD PRIMARY KEY (`codiceBarre`);

--
-- Indici per le tabelle `mps`
--
ALTER TABLE `mps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tipoTelaio` (`tipoTelaio`);

--
-- Indici per le tabelle `operazioni`
--
ALTER TABLE `operazioni`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `percorsi`
--
ALTER TABLE `percorsi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `destinazione` (`destinazione`);

--
-- Indici per le tabelle `percorsiveicoli`
--
ALTER TABLE `percorsiveicoli`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idPercorso` (`idPercorso`),
  ADD KEY `idVeicolo` (`idVeicolo`);

--
-- Indici per le tabelle `posizioni`
--
ALTER TABLE `posizioni`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idScatola` (`idScatola`);

--
-- Indici per le tabelle `processirt`
--
ALTER TABLE `processirt`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`),
  ADD KEY `idMacchina` (`idMacchina`);

--
-- Indici per le tabelle `prodottifinitidp`
--
ALTER TABLE `prodottifinitidp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idAssemblaggio` (`idAssemblaggio`);

--
-- Indici per le tabelle `ricette`
--
ALTER TABLE `ricette`
  ADD PRIMARY KEY (`tipoTelaio`);

--
-- Indici per le tabelle `routing`
--
ALTER TABLE `routing`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idLotto` (`idLotto`),
  ADD KEY `opMacchina` (`opMacchina`),
  ADD KEY `idPezzo` (`idPezzo`);

--
-- Indici per le tabelle `sald_essdp`
--
ALTER TABLE `sald_essdp`
  ADD PRIMARY KEY (`idTelaio`,`stato`);

--
-- Indici per le tabelle `scatole`
--
ALTER TABLE `scatole`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `statoordini`
--
ALTER TABLE `statoordini`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idLotto` (`idLotto`);

--
-- Indici per le tabelle `stazionilavoro`
--
ALTER TABLE `stazionilavoro`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `storicoproduzione`
--
ALTER TABLE `storicoproduzione`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idStatoOrdine` (`idStatoOrdine`),
  ADD KEY `idLotto` (`idLotto`);

--
-- Indici per le tabelle `veicoli`
--
ALTER TABLE `veicoli`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `accumulosaldaturadp`
--
ALTER TABLE `accumulosaldaturadp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `allarmirt`
--
ALTER TABLE `allarmirt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `assemblaggiodp`
--
ALTER TABLE `assemblaggiodp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `lasercutdp`
--
ALTER TABLE `lasercutdp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `lavorooperazioni`
--
ALTER TABLE `lavorooperazioni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `percorsi`
--
ALTER TABLE `percorsi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `percorsiveicoli`
--
ALTER TABLE `percorsiveicoli`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `posizioni`
--
ALTER TABLE `posizioni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `processirt`
--
ALTER TABLE `processirt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `prodottifinitidp`
--
ALTER TABLE `prodottifinitidp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `sald_essdp`
--
ALTER TABLE `sald_essdp`
  MODIFY `idTelaio` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `storicoproduzione`
--
ALTER TABLE `storicoproduzione`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `accumulosaldaturadp`
--
ALTER TABLE `accumulosaldaturadp`
  ADD CONSTRAINT `accumulosaldaturadp_ibfk_1` FOREIGN KEY (`codiceTubo`) REFERENCES `magazzinomateriali` (`codiceBarre`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `accumulosaldaturadp_ibfk_2` FOREIGN KEY (`idTelaio`) REFERENCES `sald_essdp` (`idTelaio`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limiti per la tabella `allarmirt`
--
ALTER TABLE `allarmirt`
  ADD CONSTRAINT `allarmirt_ibfk_1` FOREIGN KEY (`idMacchina`) REFERENCES `stazionilavoro` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `allarmirt_ibfk_2` FOREIGN KEY (`type`) REFERENCES `listaallarmi` (`idAllarme`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `assemblaggiodp`
--
ALTER TABLE `assemblaggiodp`
  ADD CONSTRAINT `assemblaggiodp_ibfk_2` FOREIGN KEY (`idScatola`) REFERENCES `scatole` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `assemblaggiodp_ibfk_3` FOREIGN KEY (`idTelaio`) REFERENCES `sald_essdp` (`idTelaio`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limiti per la tabella `lasercutdp`
--
ALTER TABLE `lasercutdp`
  ADD CONSTRAINT `lasercutdp_ibfk_1` FOREIGN KEY (`codiceTubo`) REFERENCES `magazzinomateriali` (`codiceBarre`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `lasercutdp_ibfk_2` FOREIGN KEY (`idAssegnazione`) REFERENCES `percorsiveicoli` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limiti per la tabella `lavorooperazioni`
--
ALTER TABLE `lavorooperazioni`
  ADD CONSTRAINT `lavorooperazioni_ibfk_1` FOREIGN KEY (`operationId`) REFERENCES `operazioni` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lavorooperazioni_ibfk_2` FOREIGN KEY (`workstationId`) REFERENCES `stazionilavoro` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `mps`
--
ALTER TABLE `mps`
  ADD CONSTRAINT `mps_ibfk_1` FOREIGN KEY (`tipoTelaio`) REFERENCES `ricette` (`tipoTelaio`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limiti per la tabella `percorsi`
--
ALTER TABLE `percorsi`
  ADD CONSTRAINT `percorsi_ibfk_1` FOREIGN KEY (`destinazione`) REFERENCES `stazionilavoro` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `percorsiveicoli`
--
ALTER TABLE `percorsiveicoli`
  ADD CONSTRAINT `percorsiveicoli_ibfk_1` FOREIGN KEY (`idPercorso`) REFERENCES `percorsi` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `percorsiveicoli_ibfk_2` FOREIGN KEY (`idVeicolo`) REFERENCES `veicoli` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `posizioni`
--
ALTER TABLE `posizioni`
  ADD CONSTRAINT `posizioni_ibfk_1` FOREIGN KEY (`idScatola`) REFERENCES `scatole` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `processirt`
--
ALTER TABLE `processirt`
  ADD CONSTRAINT `processirt_ibfk_1` FOREIGN KEY (`idMacchina`) REFERENCES `stazionilavoro` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `processirt_ibfk_2` FOREIGN KEY (`type`) REFERENCES `listaprocessi` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `prodottifinitidp`
--
ALTER TABLE `prodottifinitidp`
  ADD CONSTRAINT `prodottifinitidp_ibfk_1` FOREIGN KEY (`idAssemblaggio`) REFERENCES `assemblaggiodp` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limiti per la tabella `routing`
--
ALTER TABLE `routing`
  ADD CONSTRAINT `routing_ibfk_1` FOREIGN KEY (`idLotto`) REFERENCES `mps` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `routing_ibfk_2` FOREIGN KEY (`opMacchina`) REFERENCES `lavorooperazioni` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `routing_ibfk_3` FOREIGN KEY (`idPezzo`) REFERENCES `magazzinomateriali` (`codiceBarre`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limiti per la tabella `statoordini`
--
ALTER TABLE `statoordini`
  ADD CONSTRAINT `statoordini_ibfk_1` FOREIGN KEY (`idLotto`) REFERENCES `mps` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `storicoproduzione`
--
ALTER TABLE `storicoproduzione`
  ADD CONSTRAINT `storicoproduzione_ibfk_1` FOREIGN KEY (`idLotto`) REFERENCES `mps` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `storicoproduzione_ibfk_2` FOREIGN KEY (`idStatoOrdine`) REFERENCES `statoordini` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
